package com.example.weightloss;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;
    GridView gridView;
    Button addBtn;

    private static final int SMS_PERMISSION_CODE = 1;
    private static final double GOAL_WEIGHT = 180.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        gridView = findViewById(R.id.gridView);
        addBtn = findViewById(R.id.addWeightButton);

        loadData();
        checkSMSPermission(); // 👈 THIS CALL MUST MATCH METHOD NAME
    }

    private void loadData() {
        Cursor cursor = db.getAllWeights();

        String[] from = {"date", "weight"};
        int[] to = {R.id.dateText, R.id.weightText};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this, R.layout.grid_item, cursor, from, to, 0);

        gridView.setAdapter(adapter);
    }

    private void checkSMSPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        } else {
            checkGoalAndSendSMS();
        }
    }

    private void checkGoalAndSendSMS() {
        Cursor cursor = db.getAllWeights();

        if (cursor != null && cursor.moveToFirst()) {
            int weightIndex = cursor.getColumnIndex("weight");
            double latestWeight = cursor.getDouble(weightIndex);

            if (latestWeight <= GOAL_WEIGHT) {
                sendGoalReachedSMS();
            }
        }

        if (cursor != null) {
            cursor.close();
        }
    }

    private void sendGoalReachedSMS() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("5554", null,
                    "Congratulations! You reached your goal weight!",
                    null, null);
        } catch (Exception e) {
            Toast.makeText(this,
                    "SMS could not be sent",
                    Toast.LENGTH_SHORT).show();
        }
    }
}
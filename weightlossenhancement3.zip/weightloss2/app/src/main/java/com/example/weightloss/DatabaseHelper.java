package com.example.weightloss;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightApp.db";
    private static final int DATABASE_VERSION = 2; // incremented for upgrade

    // Tables
    private static final String TABLE_USERS = "users";
    private static final String TABLE_WEIGHT = "weights";

    // Columns
    private static final String COL_ID = "id";
    private static final String COL_DATE = "date";
    private static final String COL_WEIGHT = "weight";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Users table
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, " +
                "password TEXT)");

        // Weights table
        db.execSQL("CREATE TABLE weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "date TEXT, " +
                "weight REAL)");

        // Index AFTER table creation (performance enhancement)
        db.execSQL("CREATE INDEX idx_date ON weights(date)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
        onCreate(db);
    }

    // REGISTER USER
    public boolean registerUser(String username, String password) {

        if (username.isEmpty() || password.isEmpty()) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM users WHERE username=?",
                new String[]{username}
        );

        if (cursor.getCount() > 0) {
            cursor.close();
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert("users", null, values);

        cursor.close(); // FIXED

        return result != -1;
    }

    // LOGIN CHECK
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM users WHERE username=? AND password=?",
                new String[]{username, password});

        boolean exists = cursor.getCount() > 0;
        cursor.close(); //  FIXED

        return exists;
    }

    // ADD WEIGHT
    public boolean addWeight(String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_DATE, date);
        values.put(COL_WEIGHT, weight);

        long result = db.insert(TABLE_WEIGHT, null, values);
        return result != -1;
    }

    // GET WEIGHTS (sorted)
    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT id AS _id, date, weight FROM weights ORDER BY date DESC",
                null
        );
    }

    // DELETE
    public void deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WEIGHT, "id=?", new String[]{String.valueOf(id)}); // ✅ FIXED
    }
}
